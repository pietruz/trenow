<?php

define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_USER', getenv('DB_USER') ?: 'ibguazgk_sp526');
define('DB_PASS', getenv('DB_PASS') ?: 'S[wOAUphxQ^X5H{e');
define('DB_NAME', getenv('DB_NAME') ?: 'ibguazgk_db');

define('API_BASE', 'http://www.viaggiatreno.it/infomobilita/resteasy/viaggiatreno');

define('CACHE_TTL', 86400);

function getDB(): ?PDO {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
        } catch (PDOException $e) {
            return null;
        }
    }
    return $pdo;
}

function viaggiatrenoDate(): string {
    $tz = new DateTimeZone('Europe/Rome');
    $now = new DateTime('now', $tz);
    $days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    $months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    $w = (int)$now->format('w');
    $n = (int)$now->format('n');
    return $days[$w] . ' ' . $months[$n - 1] . ' ' . $now->format('d Y H:i:s') . ' GMT' . $now->format('O');
}

function httpGet(string $url, int $timeout = 15) {
    $ctx = stream_context_create([
        'http' => [
            'timeout' => $timeout,
            'user_agent' => 'Mozilla/5.0 (compatible; TrainTracker/1.0)',
        ]
    ]);

    $result = @file_get_contents($url, false, $ctx);
    if ($result !== false) return $result;

    $fileError = error_get_last()['message'] ?? 'sconosciuto';

    if (function_exists('curl_init')) {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; TrainTracker/1.0)',
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
        ]);
        $result = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);
        if ($result !== false && $httpCode >= 200 && $httpCode < 300) return $result;
        httpGetSetLastError("file_get_contents: $fileError | curl: $curlError (HTTP $httpCode)");
        return false;
    }

    httpGetSetLastError("file_get_contents: $fileError (cURL non installato)");
    return false;
}

$httpGetLastError = '';

function httpGetSetLastError(string $msg): void {
    global $httpGetLastError;
    $httpGetLastError = $msg;
}

function httpGetLastError(): string {
    global $httpGetLastError;
    return $httpGetLastError;
}
